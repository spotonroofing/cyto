Backup of working SVG filter goo rendering pipeline as of 2026-02-20. Preserved before attempting cached canvas optimization. To restore: copy these files back to their original locations.

## Files and original locations

| File | Original path |
|------|--------------|
| GooCanvas.tsx | src/components/BubbleMap/GooCanvas.tsx |
| BubbleMap.tsx | src/components/BubbleMap/BubbleMap.tsx |
| Bubble.tsx | src/components/BubbleMap/Bubble.tsx |
| performanceTier.ts | src/utils/performanceTier.ts |
| useBubbleLayout.ts | src/components/BubbleMap/useBubbleLayout.ts |
| globals.css | src/styles/globals.css |
