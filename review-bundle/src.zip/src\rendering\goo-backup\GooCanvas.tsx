import { useRef, useEffect } from 'react'
import { useTheme } from '@/themes'
import { IS_MOBILE, Q } from '@/utils/performanceTier'
import type { LayoutBubble, LayoutLink } from './useBubbleLayout'

interface GooCanvasProps {
  width: number
  height: number
  bubbles: LayoutBubble[]
  links: LayoutLink[]
  transform: { x: number; y: number; scale: number }
}

// ── Precomputed connection data (recomputed on layout change) ──

interface ConnectionData {
  // Source / target world positions and radii
  sx: number; sy: number; sr: number
  tx: number; ty: number; tr: number
  // Direction and distance
  dx: number; dy: number; dist: number
  // Unit tangent
  ux: number; uy: number
  // Unit normal (perpendicular)
  nx: number; ny: number
  // Colors
  sourceColor: string
  targetColor: string
  // Per-connection animation offsets (random but stable per layout)
  phaseOffset: number
  flowSpeed: number
  wobbleFreq: number
  // Fan-out counts for branch goo cleanup
  sourceFanOut: number
  targetFanOut: number
  // Bounding box for viewport culling (world coords, with padding)
  minX: number; minY: number; maxX: number; maxY: number
  // Precomputed gradient blend stops for smooth color transitions
  blendedColors: [string, string, string]
  // Fraction of gradient covered by source/target cell radii (for edge-aligned stops)
  sourceEdgeFrac: number
  targetEdgeFrac: number
}

interface BlobData {
  x: number; y: number; radius: number
  color: string
  phaseIndex: number
  // Per-blob animation offsets
  breathePhase: number
  wobblePhase: number
  deformFreq: number
  // Nucleus-specific
  nucleusBreathePhase: number // independent breathing phase (decoupled from membrane)
  nucleusHarmonics: number[]  // 4-6 random amplitudes for multi-harmonic shape
  nucleusPhases: number[]     // matching phase offsets
  nucleusRotSpeed: number     // rotation speed
}

// ── Sampling helpers ──────────────────────────────────────────

function sampleConnection(
  conn: ConnectionData,
  t: number, // 0..1 along path
  time: number,
): { x: number; y: number; width: number } {
  // Gentle organic curve bow
  const curveBow = Math.sin(t * Math.PI) * conn.dist * 0.008
  // Flow wave, damped at endpoints for clean junction merge
  const dampEnds = Math.sin(t * Math.PI)  // 0 at edges, 1 at center
  const flowWave = Math.sin(time * conn.flowSpeed + t * 4 + conn.phaseOffset) * 4 * dampEnds

  const x = conn.sx + conn.dx * t + conn.nx * (curveBow + flowWave)
  const y = conn.sy + conn.dy * t + conn.ny * (curveBow + flowWave)

  // ── Width: consistent tube with smooth junction flare ──
  const smallerR = Math.min(conn.sr, conn.tr)

  // Minimum tube width: ~24% of smaller radius (half-width),
  // total visible width ≈ 48% of radius ≈ 24% of diameter
  const midWidth = smallerR * 0.24

  // Junction flare: use actual endpoint radius for organic merge into orb
  const nearEndR = t < 0.5 ? conn.sr : conn.tr
  const nearFan = t < 0.5 ? (conn.sourceFanOut || 1) : (conn.targetFanOut || 1)
  const fanScale = nearFan > 2 ? 0.78 : 1.0
  const endWidth = nearEndR * 0.52 * fanScale

  // Smooth cosine flare over first/last 25% of connection path
  const distFromEdge = Math.min(t, 1 - t) * 2  // 0 at edges, 1 at center
  const flareZone = 0.5  // transition zone (distFromEdge 0→0.5 = first/last 25%)
  const flareT = Math.min(distFromEdge / flareZone, 1)
  const flareEase = 0.5 * (1 - Math.cos(Math.PI * flareT))

  // Interpolate: endWidth at junctions, midWidth in tube section
  const width = Math.max(midWidth * 0.9, endWidth + (midWidth - endWidth) * flareEase)

  return { x, y, width }
}

// ── Viewport culling helper ──────────────────────────────────

function isInViewport(
  minX: number, minY: number, maxX: number, maxY: number,
  tx: number, ty: number, scale: number,
  viewW: number, viewH: number,
): boolean {
  // Convert world-space AABB to screen-space
  const screenMinX = minX * scale + tx
  const screenMinY = minY * scale + ty
  const screenMaxX = maxX * scale + tx
  const screenMaxY = maxY * scale + ty
  // Padding scales with zoom to account for goo filter bleed (stdDev scales linearly)
  const pad = Math.max(60, 40 * scale)
  return screenMaxX >= -pad && screenMinX <= viewW + pad &&
         screenMaxY >= -pad && screenMinY <= viewH + pad
}

// ── Gamma-corrected color blend for perceptually smooth gradients ──

function blendHex(c1: string, c2: string, t: number): string {
  const r1 = parseInt(c1.slice(1, 3), 16)
  const g1 = parseInt(c1.slice(3, 5), 16)
  const b1 = parseInt(c1.slice(5, 7), 16)
  const r2 = parseInt(c2.slice(1, 3), 16)
  const g2 = parseInt(c2.slice(3, 5), 16)
  const b2 = parseInt(c2.slice(5, 7), 16)
  // Blend in squared (gamma) space for perceptual smoothness
  const r = Math.round(Math.sqrt(r1 * r1 * (1 - t) + r2 * r2 * t))
  const g = Math.round(Math.sqrt(g1 * g1 * (1 - t) + g2 * g2 * t))
  const b = Math.round(Math.sqrt(b1 * b1 * (1 - t) + b2 * b2 * t))
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`
}

// ── Main component ────────────────────────────────────────────

export function GooCanvas({ width, height, bubbles, links, transform }: GooCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const connectionsRef = useRef<ConnectionData[]>([])
  const blobsRef = useRef<BlobData[]>([])
  const animFrameRef = useRef<number>(0)
  // Store transform in a ref so animation loop reads it without restarting
  const transformRef = useRef(transform)
  const { phaseColor, palette } = useTheme()
  const paletteRef = useRef(palette)

  // Keep refs in sync without restarting animation loop
  useEffect(() => { transformRef.current = transform }, [transform])
  useEffect(() => { paletteRef.current = palette }, [palette])

  // Precompute connection and blob data when layout changes
  useEffect(() => {
    const conns: ConnectionData[] = []
    for (const link of links) {
      const sx = link.source.x, sy = link.source.y, sr = link.source.radius
      const tx = link.target.x, ty = link.target.y, tr = link.target.radius
      const dx = tx - sx, dy = ty - sy
      const dist = Math.sqrt(dx * dx + dy * dy)
      if (dist < 1) continue

      const ux = dx / dist, uy = dy / dist
      const nx = -uy, ny = ux

      // Compute bounding box with padding for wobble
      const pad = Math.max(sr, tr) * 0.6
      const minX = Math.min(sx, tx) - pad
      const minY = Math.min(sy, ty) - pad
      const maxX = Math.max(sx, tx) + pad
      const maxY = Math.max(sy, ty) + pad

      const sourceColor = phaseColor(link.sourcePhaseIndex)
      const targetColor = phaseColor(link.targetPhaseIndex)

      // Fraction of gradient hidden under each cell — the gradient should stay
      // at pure source/target color through these zones so no "hint" of the
      // other color appears at the cell membrane edge.
      const rawSourceEdge = sr / dist
      const rawTargetEdge = 1 - tr / dist
      // Clamp so the visible transition zone is at least 20% of the gradient
      const sourceEdgeFrac = Math.min(rawSourceEdge, 0.4)
      const targetEdgeFrac = Math.max(rawTargetEdge, 0.6)

      conns.push({
        sx, sy, sr, tx, ty, tr,
        dx, dy, dist, ux, uy, nx, ny,
        sourceColor,
        targetColor,
        phaseOffset: Math.random() * Math.PI * 2,
        flowSpeed: 0.4 + Math.random() * 0.3,
        wobbleFreq: 3 + Math.random() * 2,
        sourceFanOut: 1,
        targetFanOut: 1,
        minX, minY, maxX, maxY,
        blendedColors: [
          blendHex(sourceColor, targetColor, 0.25),
          blendHex(sourceColor, targetColor, 0.5),
          blendHex(sourceColor, targetColor, 0.75),
        ],
        sourceEdgeFrac,
        targetEdgeFrac,
      })
    }

    // Count how many connections share each endpoint
    const endpointCount = new Map<string, number>()
    for (const conn of conns) {
      const sKey = `${conn.sx},${conn.sy}`
      const tKey = `${conn.tx},${conn.ty}`
      endpointCount.set(sKey, (endpointCount.get(sKey) || 0) + 1)
      endpointCount.set(tKey, (endpointCount.get(tKey) || 0) + 1)
    }

    // Store fan-out counts on each connection
    for (const conn of conns) {
      const sKey = `${conn.sx},${conn.sy}`
      const tKey = `${conn.tx},${conn.ty}`
      conn.sourceFanOut = endpointCount.get(sKey) || 1
      conn.targetFanOut = endpointCount.get(tKey) || 1
    }

    connectionsRef.current = conns

    const blobs: BlobData[] = bubbles.map((b) => ({
      x: b.x,
      y: b.y,
      radius: b.radius,
      color: phaseColor(b.phaseIndex),
      phaseIndex: b.phaseIndex,
      breathePhase: b.phaseIndex * 0.9 + Math.random() * 0.5,
      wobblePhase: Math.random() * Math.PI * 2,
      deformFreq: 2 + Math.random(),
      // Multi-harmonic nucleus shape — each blob gets unique deformation
      nucleusBreathePhase: Math.random() * Math.PI * 2,  // independent from membrane breathePhase
      nucleusHarmonics: Array.from({ length: 5 }, () => 1.5 + Math.random() * 4),
      nucleusPhases: Array.from({ length: 5 }, () => Math.random() * Math.PI * 2),
      nucleusRotSpeed: 0.08 + Math.random() * 0.12,
    }))
    blobsRef.current = blobs
  }, [links, bubbles, palette])

  // Animation loop — does NOT depend on transform (reads from ref)
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || width === 0 || height === 0) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = Math.min(window.devicePixelRatio || 1, Q.canvasDpr)
    canvas.width = width * dpr
    canvas.height = height * dpr
    canvas.style.width = `${width}px`
    canvas.style.height = `${height}px`

    const SAMPLES_PER_100PX = Q.gooSamplesPerPx
    const MIN_SEGMENTS = Q.gooMinSegments
    const BLOB_STEPS = Q.gooBlobSteps
    const NUCLEUS_STEPS = Q.gooNucleusSteps
    const NUCLEUS_HARMONICS = Q.gooNucleusHarmonics

    let time = 0
    let lastFrameTime = 0
    const TARGET_DT = Q.gooTargetDt
    const IDLE_DT = Q.gooIdleDt
    const IDLE_THRESHOLD = 2000 // ms of no transform change before entering idle
    let lastKnownTf = { x: 0, y: 0, scale: 0 }
    let lastTransformChangeTime = performance.now()

    const draw = (timestamp: number) => {
      // Track transform changes for idle detection
      const tf = transformRef.current
      if (tf.x !== lastKnownTf.x || tf.y !== lastKnownTf.y || tf.scale !== lastKnownTf.scale) {
        lastKnownTf = { x: tf.x, y: tf.y, scale: tf.scale }
        lastTransformChangeTime = timestamp
      }

      const isIdle = (timestamp - lastTransformChangeTime) > IDLE_THRESHOLD
      const effectiveDT = isIdle ? IDLE_DT : TARGET_DT

      // Frame rate limiting (adaptive: slower when idle)
      if (timestamp - lastFrameTime < effectiveDT * 0.8) {
        animFrameRef.current = requestAnimationFrame(draw)
        return
      }
      const prevFrame = lastFrameTime
      lastFrameTime = timestamp
      // Use real elapsed time so wobble speed is independent of frame rate
      time += prevFrame > 0 ? Math.min((timestamp - prevFrame) / 1000, 0.1) : 0.016

      const pal = paletteRef.current

      ctx.clearRect(0, 0, canvas.width, canvas.height)
      ctx.save()
      ctx.scale(dpr, dpr)
      ctx.translate(tf.x, tf.y)
      ctx.scale(tf.scale, tf.scale)

      const connections = connectionsRef.current
      const blobs = blobsRef.current

      // ── Draw connections as thick tapered filled paths ──

      for (const conn of connections) {
        // Viewport culling
        if (!isInViewport(conn.minX, conn.minY, conn.maxX, conn.maxY,
            tf.x, tf.y, tf.scale, width, height)) continue

        const segments = Math.max(MIN_SEGMENTS, Math.floor(conn.dist / 100 * SAMPLES_PER_100PX))

        // Sample points along the connection
        const points: { x: number; y: number; width: number }[] = []
        for (let i = 0; i <= segments; i++) {
          const t = i / segments
          points.push(sampleConnection(conn, t, time))
        }

        // Compute upper and lower outlines
        const upper: { x: number; y: number }[] = []
        const lower: { x: number; y: number }[] = []

        for (let i = 0; i < points.length; i++) {
          const p = points[i]!
          // Compute local normal direction
          let lnx: number, lny: number
          if (i === 0) {
            const next = points[1]!
            const tdx = next.x - p.x, tdy = next.y - p.y
            const tlen = Math.sqrt(tdx * tdx + tdy * tdy) || 1
            lnx = -tdy / tlen; lny = tdx / tlen
          } else if (i === points.length - 1) {
            const prev = points[i - 1]!
            const tdx = p.x - prev.x, tdy = p.y - prev.y
            const tlen = Math.sqrt(tdx * tdx + tdy * tdy) || 1
            lnx = -tdy / tlen; lny = tdx / tlen
          } else {
            const prev = points[i - 1]!, next = points[i + 1]!
            const tdx = next.x - prev.x, tdy = next.y - prev.y
            const tlen = Math.sqrt(tdx * tdx + tdy * tdy) || 1
            lnx = -tdy / tlen; lny = tdx / tlen
          }
          // Edge wobble — independent sine-wave displacement per edge for organic ripple
          // Skipped on mobile (Q.gooEdgeWobble === false) — saves 4 sin() per segment per connection
          let wU: number, wL: number
          if (Q.gooEdgeWobble) {
            const edgeT = i / segments
            const wDamp = Math.sin(edgeT * Math.PI)
            const wobbleUpper = (
              Math.sin(time * 3.2 + edgeT * 6 + conn.phaseOffset) * 2.5
              + Math.sin(time * 2.1 + edgeT * 3.5 + conn.phaseOffset * 1.7) * 1.5
            ) * wDamp
            const wobbleLower = (
              Math.sin(time * 2.8 + edgeT * 5.5 + conn.phaseOffset + 2.1) * 2.5
              + Math.sin(time * 2.3 + edgeT * 3 + conn.phaseOffset * 1.3 + 1.0) * 1.5
            ) * wDamp
            wU = p.width + wobbleUpper
            wL = p.width + wobbleLower
          } else {
            wU = p.width
            wL = p.width
          }
          upper.push({ x: p.x + lnx * wU, y: p.y + lny * wU })
          lower.push({ x: p.x - lnx * wL, y: p.y - lny * wL })
        }

        // Draw filled shape with smooth curves
        ctx.beginPath()

        // Upper edge: forward
        ctx.moveTo(upper[0]!.x, upper[0]!.y)
        for (let i = 1; i < upper.length; i++) {
          const prev = upper[i - 1]!
          const curr = upper[i]!
          const cpx = (prev.x + curr.x) / 2
          const cpy = (prev.y + curr.y) / 2
          ctx.quadraticCurveTo(prev.x, prev.y, cpx, cpy)
        }
        ctx.lineTo(upper[upper.length - 1]!.x, upper[upper.length - 1]!.y)

        // Lower edge: reverse
        for (let i = lower.length - 2; i >= 0; i--) {
          const next = lower[i + 1]!
          const curr = lower[i]!
          const cpx = (next.x + curr.x) / 2
          const cpy = (next.y + curr.y) / 2
          ctx.quadraticCurveTo(next.x, next.y, cpx, cpy)
        }
        ctx.lineTo(lower[0]!.x, lower[0]!.y)

        ctx.closePath()

        // Smooth gradient — edge-aligned so pure colors extend through cell radii
        // and the visible transition only occurs in the gap between cell edges
        const grad = ctx.createLinearGradient(conn.sx, conn.sy, conn.tx, conn.ty)
        const s = conn.sourceEdgeFrac
        const e = conn.targetEdgeFrac
        const range = e - s
        grad.addColorStop(0, conn.sourceColor)
        grad.addColorStop(s, conn.sourceColor)
        grad.addColorStop(s + range * 0.25, conn.blendedColors[0]!)
        grad.addColorStop(s + range * 0.5, conn.blendedColors[1]!)
        grad.addColorStop(s + range * 0.75, conn.blendedColors[2]!)
        grad.addColorStop(e, conn.targetColor)
        grad.addColorStop(1, conn.targetColor)
        ctx.fillStyle = grad
        ctx.fill()

      }

      // ── Draw milestone blobs with organic deformation ──

      for (const blob of blobs) {
        // Viewport culling
        const blobPad = blob.radius + 10
        if (!isInViewport(blob.x - blobPad, blob.y - blobPad,
            blob.x + blobPad, blob.y + blobPad,
            tf.x, tf.y, tf.scale, width, height)) continue

        // Breathing radius
        const breathe = Math.sin(time * 0.5 + blob.breathePhase) * 3.6
        const baseR = blob.radius + breathe

        // Organic blob shape: draw with sinusoidal radius variation
        const deformA = Math.sin(time * 0.3 + blob.wobblePhase) * 3.6
        const deformB = Math.cos(time * 0.25 + blob.wobblePhase * 1.3) * 2.4
        const rotPhase = time * -0.15 + blob.phaseIndex * 0.5

        ctx.beginPath()
        for (let i = 0; i <= BLOB_STEPS; i++) {
          const angle = (i / BLOB_STEPS) * Math.PI * 2
          const r = baseR
            + deformA * Math.sin(blob.deformFreq * angle + rotPhase)
            + deformB * Math.cos((blob.deformFreq + 1) * angle - rotPhase * 0.7)
          const px = blob.x + Math.cos(angle) * r
          const py = blob.y + Math.sin(angle) * r
          if (i === 0) ctx.moveTo(px, py)
          else ctx.lineTo(px, py)
        }
        ctx.closePath()
        ctx.fillStyle = blob.color
        ctx.fill()
      }

      // ── Draw nucleus shapes ──
      for (const blob of blobs) {
        // Viewport culling (same bounds as blob)
        const blobPad = blob.radius + 10
        if (!isInViewport(blob.x - blobPad, blob.y - blobPad,
            blob.x + blobPad, blob.y + blobPad,
            tf.x, tf.y, tf.scale, width, height)) continue

        const nucleusR = blob.radius * 0.68
        const breathe = Math.sin(time * 0.7 + blob.nucleusBreathePhase) * 2.5

        // Multi-harmonic organic shape
        ctx.beginPath()
        for (let i = 0; i <= NUCLEUS_STEPS; i++) {
          const angle = (i / NUCLEUS_STEPS) * Math.PI * 2
          let r = nucleusR + breathe

          // Sum harmonics (fewer on mobile)
          const harmonicCount = Math.min(NUCLEUS_HARMONICS, blob.nucleusHarmonics.length)
          for (let h = 0; h < harmonicCount; h++) {
            const freq = h + 2  // frequencies 2, 3, 4, 5, 6
            const amp = blob.nucleusHarmonics[h]!
            const phase = blob.nucleusPhases[h]! + time * blob.nucleusRotSpeed * (h % 2 === 0 ? -1 : 0.7)
            r += amp * Math.sin(freq * angle + phase)
          }

          // Clamp so it doesn't exceed membrane
          r = Math.max(nucleusR * 0.6, Math.min(nucleusR * 1.25, r))

          const px = blob.x + Math.cos(angle) * r
          const py = blob.y + Math.sin(angle) * r
          if (i === 0) ctx.moveTo(px, py)
          else ctx.lineTo(px, py)
        }
        ctx.closePath()

        // Slightly brighter than the membrane blob
        ctx.globalAlpha = pal.nucleus
        ctx.fillStyle = blob.color
        ctx.fill()
        ctx.globalAlpha = 1
      }

      ctx.restore()
      animFrameRef.current = requestAnimationFrame(draw)
    }

    animFrameRef.current = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(animFrameRef.current)
  }, [width, height, bubbles, palette])
  // NOTE: transform removed from deps — read from ref instead

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0"
      style={{
        zIndex: 1,
        pointerEvents: 'none',
        // Mobile uses lighter goo filter (stdDeviation=7 vs 12, ~4x cheaper)
        filter: IS_MOBILE ? 'url(#goo-filter-mobile)' : 'url(#goo-filter)',
        opacity: palette.goo,
      }}
    />
  )
}
