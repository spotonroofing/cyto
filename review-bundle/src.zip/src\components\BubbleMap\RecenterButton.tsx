import { FloatingButton } from '@/components/UI/FloatingButton'

interface RecenterButtonProps {
  onRecenter: () => void
}

export function RecenterButton({ onRecenter }: RecenterButtonProps) {
  return (
    <FloatingButton onClick={onRecenter} position="bottom-center">
      Go to current
    </FloatingButton>
  )
}
